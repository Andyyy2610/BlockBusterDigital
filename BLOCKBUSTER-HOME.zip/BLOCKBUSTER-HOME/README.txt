BLOCKBUSTER - HOME (sin JavaScript)

Estructura:
- index.html
- css/main.css
- img/ (todas las imágenes locales utilizadas por el Home)

Esta versión no incluye JavaScript para que otro integrante del equipo pueda implementar las validaciones, filtros, carrito y demás interacciones.

Las rutas de imágenes son locales, por ejemplo: img/duna-parte-dos.jpg
Desde CSS, el banner usa: ../img/banner-cine.jpg

El menú deja preparados enlaces a las vistas requeridas por la evaluación: productos, nosotros, blog, contacto, login, registro y carrito.


IMAGENES DE PELICULAS: Las tarjetas usan posters reales mediante enlaces directos de TMDB para mostrar las portadas originales de las peliculas. Requieren conexion a Internet para cargar. Los demas recursos del proyecto siguen en la carpeta img/.
